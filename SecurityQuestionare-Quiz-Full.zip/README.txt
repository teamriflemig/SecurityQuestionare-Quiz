
Security+ Quiz App - Quick Start
1. Open a terminal in this folder.
2. Run: npm install
3. Run: npm run dev
4. Open the Local URL shown (usually http://localhost:5173)
